#include "linuxCMD.c"
#define PORT 1234

//***** Global Variables *****
char ans[MAX];
char line[MAX];    
int _get(char*), _put(char*), runCommand(char*);
//get: 
int _get(char* pathname){
	struct stat mystat, *sp = &mystat;
	if (lstat(pathname, sp) < 0){
		printf("\tError: No Such File '%s'\n", pathname);
		return -1;
	}
	if (!S_ISREG(sp->st_mode)){
		printf("\tError: '%s' is Not a Regular File\n", pathname);
		return -1;
	}
	char buff[MAX];
	int fd = open(pathname, O_RDONLY), n;
	if(fd < 0)
	{
		printf("\tError: Unable to Open '%s' for Reading\n", pathname);
		return -1;
	}
	else
	{
		printf("Filename = '%s'\nExpecting %ld bytes\n", pathname, sp->st_size);
		bzero(buff,MAX);
		while((n = read(fd, buff, MAX)) != 0) 
		{
		    n = write(cfd, buff, n); 
		    bzero(buff,MAX);
		}
		printf("File Transfer Complete\n");
        write(cfd, EOF_STR , strlen(EOF_STR)+1);
	}
	close(fd); 
}

//put: 
int _put(char* pathname){
	struct stat mystat, *sp = &mystat;
	if (lstat(pathname, sp) < 0){
		printf("\tError: No Such File '%s'\n", pathname);
		return -1;
	}
	if (!S_ISREG(sp->st_mode)){
		printf("\tError: '%s' is Not a Regular File\n", pathname);
		return -1;
	}
	char buff[MAX];
	int fd = open(pathname, O_RDONLY), n;
    if(fd < 0)
    {
		printf("\tError: Unable to Open '%s' for Reading\n", pathname);
        return -1;
    }
    else{
    	printf("Pathname = '%s' || Size %ld bytes\n", pathname, sp->st_size);
		bzero(buff,MAX);
		while((n = read(fd, buff, MAX)) != 0) 
		{
		    n = write(cfd, buff, n);
		    bzero(buff,MAX);
		}
		printf("File Transfer Complete\n");
        write(cfd, EOF_STR , strlen(EOF_STR)+1);
    }
	close(fd);
	return 0;
}

int runCommand(char *line){
	char command[10], pathname[MAX];
	int cmdIndex = getLineInfo(line, command, pathname), r = -1;
	if(cmdIndex == -1){
		if(!strcmp(command, "get")){ r = _get(pathname); }
		else if(!strcmp(command, "put")){ r = _put(pathname); }
		else{ 
			printf("INVALID: '%s'\n", line);
			strcat(line, " -> Invalid Input"); 
			r = -1;
		}
	}
	else{
		int value = fcmds[cmdIndex](pathname);
		if(value == 0){
			r = 0;
		}
		else if(value == -1){
			r = -1;
		}
		else{ 
			char *str = (char*)value;
			if(str != NULL){
				strcpy(line, str);
				r = 1;
			}
			else{
				printf("\tError: Returned Invalid String Address\n");
				r = -1;

			}
		}
	}
	if(r == 0){ strcat(line, " -> SUCCESS"); }
	else if(r == -1){ strcat(line, " -> FAILURE"); }
	return r;
}

int main(int argc, char *argv[], char *env[])
{
  int sfd, cfd, len; 
  struct sockaddr_in saddr, caddr; 
  int i, length;
    
  printf("1. create a socket\n");
  sfd = socket(AF_INET, SOCK_STREAM, 0); 
  if (sfd < 0) { 
    printf("socket creation failed\n"); 
    exit(0); 
  }
    
  printf("2. fill in server IP and port number\n");
  bzero(&saddr, sizeof(saddr)); 
  saddr.sin_family = AF_INET; 
  saddr.sin_addr.s_addr = inet_addr("127.0.0.1"); 
  saddr.sin_port = htons(PORT);
    
  printf("3. bind socket to server\n");
  if ((bind(sfd, (struct sockaddr *)&saddr, sizeof(saddr))) != 0) { 
    printf("socket bind failed\n"); 
    exit(0); 
  }
  if ((listen(sfd, 5)) != 0) { 
    printf("Listen failed\n"); 
    exit(0); 
  }
  while(1){
    length = sizeof(caddr);
    cfd = accept(sfd, (struct sockaddr *)&caddr, &length);
    if (cfd < 0){
      printf("server: accept error\n");
      exit(1);
    }

    printf("server: accepted a client connection from\n");
    printf("-----------------------------------------------\n");
    printf("    IP=%s  port=%d\n", "127.0.0.1", ntohs(caddr.sin_port));
    printf("-----------------------------------------------\n");
		while(1){
			char line[MAX];
			memset(line, 0,MAX); 
			int bytes = 0;
			bytes = read(cfd, line, MAX);
			if (bytes == 0){
				printf("Server: Client Died, Server Loops\n");
				close(cfd);
				break;
			}
			printf("Server: Read %d Bytes || Input = '%s'\n", bytes, line);
			isServer = true;	
			int result = runCommand(line);
			int n = strlen(line)+1;
			bytes = write(cfd, &n, sizeof(int));
			bytes = write(cfd, line, n);
			printf("Server: Wrote %d Bytes || Output = '%s'\n", bytes, result > -1? "SUCCESS" : "FAILURE");
			printf("Server: Ready For Next Request\n");
			memset(line, 0, n); 
		}
	}
	return 0;
}