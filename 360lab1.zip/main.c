#include "myprint.c"
int main(int argc, char* argv[], char* env[]) {
	myprintf("cha=%c string=%s      dec=%d hex=%x oct=%o neg=%d\n",
		'A', "this is a test", 100, 100, 100, -100);
}