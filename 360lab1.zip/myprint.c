#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
//1-1
typedef unsigned int u32;

char* tab = "0123456789ABCDEF";
int  BASE = 10;

int rpu(u32 x)
{
    char c;
    if (x) {
        c = tab[x % BASE];
        rpu(x / BASE);
        putchar(c);
    }
}

int printu(u32 x)
{
    (x == 0) ? putchar('0') : rpu(x);
    putchar(' ');
}
int prints(char *s) {
    if (s == NULL)
        return;
    else
        return prints(++s);
}
 
//2-2
int  printd(int x) {
    (x == 0) ? putchar('0') : rpu(x);
    (x < 0) ? putchar('-') : rpu(x);
    putchar(' ');
    
}
int rpu1(u32 x)
{
    char c;
    if (x) {
        c = tab[x % 16];
        rpu(x / 16);
        putchar(c);
    }
}
int  printx(u32 x) {
    (x == 0) ? putchar('0x') : rpu(x);
    
}
int rpu2(u32 x)
{
    char c;
    if (x) {
        c = tab[x % 8];
        rpu(x / 8);
        putchar(c);
    }
}
int  printo(u32 x) {
    (x == 0) ? putchar('0') : rpu(x);
}

int myprintf(char *fmt) {
    va_list temp;
    va_start(temp,fmt);
    for (int i = 0; fmt[i] != NULL; i++) {
        if (*fmt != 0) {
            char a = fmt[i++];
            switch (a) {
            case 'HEX': 
                printx (va_arg(temp, u32));
                break;
            case 'INT': 
                printd(va_arg(temp, int));
                break;
            case 'OCT': 
                printo (va_arg(temp, u32));
                break;
            case 'UINT': 
                printu(va_arg(temp, u32));
                break;
            case 'STR': 
                prints(va_arg(temp, char*));
                break;
            default: putchar(va_arg(temp, int));

            }

        }
        else { putchar(fmt[i]); }
    }
    va_end(temp);
    return 1;
}
