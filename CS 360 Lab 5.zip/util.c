/*********** util.c file ****************/
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <ext2fs/ext2_fs.h>
#include <string.h>
#include <libgen.h>
#include <sys/stat.h>
#include <time.h>

#include "type.h"

/**** globals defined in main.c file ****/
extern MINODE minode[NMINODE];
extern MINODE *root;
extern PROC   proc[NPROC], *running;

extern char gpath[128];
extern char *name[64];
extern int n;

extern int fd, dev;
extern int nblocks, ninodes, bmap, imap, iblk;

extern char line[128], cmd[32], pathname[128];

int get_block(int dev, int blk, char *buf)
{
   lseek(dev, (long)blk*BLKSIZE, 0);
   read(dev, buf, BLKSIZE);
}   

int put_block(int dev, int blk, char *buf)
{
   lseek(dev, (long)blk*BLKSIZE, 0);
   write(dev, buf, BLKSIZE);
}   

char** tokenize(char *pathname)
{
   int i = 0;
   char** name;
   char* tmp;
   name = (char**)malloc(sizeof(char*)*256);
   name[0] = strtok(pathname, "/");
   i = 1;
   while ((name[i] = strtok(NULL, "/")) != NULL) { i++;}
   name[i] = 0;
   i = 0;
   while(name[i])
   {
      tmp = (char*)malloc(sizeof(char)*strlen(name[i]));
      strcpy(tmp, name[i]);
      name[i] = tmp;
      i++;
   }
   return name;
}

MINODE *iget(int dev, int ino)
{
   int i = 0, blk, offset;
   char buf[BLKSIZE];
   MINODE *mip = NULL;
   for(i = 0; i < NMINODE; i++)
   {
      if(minode[i].refCount && minode[i].ino == ino && minode[i].dev == dev)
      {
         mip = &minode[i];
         minode[i].refCount++;
         return mip;
      }
   }
   i = 0;
   while(minode[i].refCount > 0 && i < NMINODE) { i++;}
   if(i == 64)
   {
      return 0;
   }
   blk = (ino-1)/8 + iblk;
   offset = (ino-1)%8;
   get_block(dev, blk, buf);
   ip = (INODE *)buf + offset;
   memcpy(&(minode[i].INODE), ip, sizeof(INODE)); 
   minode[i].dev = dev;
   minode[i].ino = ino;
   minode[i].refCount = 1;
   minode[i].dirty = 0;
   minode[i].mounted = 0;
   minode[i].mptr = NULL;
   return &minode[i];
}

void iput(int dev, MINODE *mip)
{
   int offset;
   char buf[BLKSIZE];
   INODE *ip;

   if (mip==0) 
      return;

   mip->refCount--;
 
   if (mip->refCount > 0) return;
   if (!mip->dirty)       return;
 
   int blk = (mip->ino-1)/8 + iblk;
   offset = (mip->ino-1)%8;

   get_block(dev, blk, buf); 

   ip = (INODE*)buf + offset;
   memcpy(ip, &(mip->INODE), sizeof(INODE)); 
   put_block(mip->dev, blk, buf);
   mip->refCount = 0;
   return 1;
} 

int search(int dev, char *str, INODE *ip)
{
   char *cp;
   DIR *dp;
   char buf[BLKSIZE], temp[256];

   for(int i = 0; i < 12; i++)
   {
      if(ip->i_block[i] == 0){break;} 
      get_block(dev, ip->i_block[i], buf);
      dp = (DIR *)buf;
      cp = buf;

      while(cp < buf+BLKSIZE)
      {
         memset(temp, 0, 256);
         strncpy(temp, dp->name, dp->name_len);
         if(strcmp(str, temp) == 0){ return dp->inode;}
         cp += dp->rec_len;
         dp = (DIR*)cp;
      }
   }
   return 0;
}

int getino(int dev, char *path)
{
   int ino = 0, i = 0;
   char **tokens;
   MINODE *mip = NULL;
   if(path && path[0])
   {
      tokens = tokenize(path);
   }
   else
   {
      ino = running->cwd->ino;
      return ino;
   }
   if(path[0]=='/')
   {
      ip = &(root->INODE);
      ino = root->ino;
   }
   else 
   {
      ip = &(running->cwd->INODE);
   }
   while(tokens[i])
   {
      ino = search(dev, tokens[i], ip);
      if(0 >= ino) 
      {
         if(mip){ iput(mip->dev, mip);}
         return -1;
      }
      if(mip) { iput(mip->dev, mip);}
      i++;
      if(tokens[i])
      {
         mip = iget(dev, ino);
         ip = &(mip->INODE);
      }
   }
   i = 0;
   while(tokens[i])
   {
    free(tokens[i]);
    i++;
   }
   if(mip) { iput(mip->dev, mip);}
   return ino;
}

// These 2 functions are needed for pwd()
int findmyname(MINODE *parent, u32 myino, char myname[ ]) 
{
  // WRITE YOUR code here
  // search parent's data block for myino; SAME as search() but by myino
  // copy its name STRING to myname[ ] 
}

int findino(MINODE *mip, u32 *myino, u32 *parent) // myino = i# of . return i# of ..
{
  // mip points at a DIR minode
  // WRITE your code here: myino = ino of .  return ino of ..
  // all in i_block[0] of this DIR INODE.
}

int searchByIno(int dev, int ino, INODE *ip, char* temp)
{
   char *cp;
   DIR *dp;
   char buf[BLKSIZE];
   for(int i = 0; i < 12; i++)
   {
      if(ip->i_block[i] == 0){ break;}
      get_block(dev, ip->i_block[i], buf);
      dp = (DIR *)buf;
      cp = buf;
      while(cp < buf+BLKSIZE)
      {
         if(ino == dp->inode)
         {
            strncpy(temp, dp->name, dp->name_len);
            return 1;
         }
         cp += dp->rec_len;
         dp = (DIR*)cp;
      }
   }
   return 0;
}

int findparent(char *pathname)
{
   int i = 0;
   while(i < strlen(pathname))
   {
      if(pathname[i] == '/')
         return 1;
      i++;
   }
   return 0;
}