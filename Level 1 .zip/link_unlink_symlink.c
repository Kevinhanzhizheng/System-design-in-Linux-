/************* link_unlink_symlink.c file **************/
#include "type.h"
int _link(char* pathname, char* parameter)
{
    char parent[256], child[256], buf[BLKSIZE];
    int newRec;
    DIR *dp;
    //check file exist
    int ino = getino(dev, pathname);

    if(ino <= 0)
    {
        printf("File DNE.\n");
        return -1;
    }
    MINODE *mip = iget(dev, ino);
    //check isreg
    if(!S_ISREG(mip->INODE.i_mode))
    {
        printf("Not regular\n");
        iput(mip->dev, mip);
        return -1;
    }
    dname(parameter, parent);
    bname(parameter, child);
    //check second file
    int ino2 = getino(mip->dev, parent);
    if(ino2<=0)
    {
        printf("File DNE");
        iput(mip->dev, mip);
        return -1;
    }
    MINODE *mip2 = iget(mip->dev, ino2);
    //check dir parent
    if(!S_ISDIR(mip2->INODE.i_mode))
    {
        printf("Not a directory\n");
        iput(mip->dev, mip);
        iput(mip2->dev, mip2);
        return -1;
    }
    //check if filename used
    ino2 = search(mip2->dev, child, &(mip2->INODE));
    if(ino2 > 0)
    {
        printf("File exists\n");
        iput(mip->dev, mip);
        iput(mip2->dev, mip2);
        return -1;
    }

    memset(buf, 0, BLKSIZE);
    int needLen = 4*((8+strlen(child)+3)/4);
    int bnumber = findLastBlock(mip2);
    //check if enough room
    get_block(mip2->dev, bnumber, buf);
    dp = (DIR*)buf;
    char *cp = buf;
    while((dp->rec_len + cp) < buf+BLKSIZE)
    {
        cp += dp->rec_len;
        dp = (DIR*)cp;
    }
    int idealLen = 4*((8+dp->name_len+3)/4);
    if(dp->rec_len - idealLen >= needLen)
    {
        newRec = dp->rec_len - idealLen;
        dp->rec_len = idealLen;
        cp += dp->rec_len;
        dp = (DIR*)cp;
        dp->inode = ino;
        dp->name_len = strlen(child);
        strncpy(dp->name, child, dp->name_len);
        dp->rec_len = newRec;
    }
    else //allocate
    {
        bnumber = balloc(mip2->dev);
        dp = (DIR*)buf;
        dp->inode = ino;
        dp->name_len = strlen(child);
        strncpy(dp->name, child, dp->name_len);
        dp->rec_len = BLKSIZE;
        addLastBlock(mip2, bnumber);
    }

    put_block(mip2->dev, bnumber, buf);
    mip->dirty = 1;
    mip->INODE.i_links_count++;
    memset(buf, 0, BLKSIZE);
    findino(mip2->dev, mip2->ino, &running->cwd->INODE, buf);
    iput(mip->dev, mip);
    iput(mip2->dev, mip2);
    return 1;
}

int _rm_child(MINODE *pip, char *child)
{
    int size, found = 0;
    char *cp, *cp2;
    DIR *dp, *dp2, *dpPrev;
    char buf[BLKSIZE], buf2[BLKSIZE], temp[256];

    memset(buf2, 0, BLKSIZE);
    //check direct
    for(int i = 0; i < 12; i++)
    {
        if(pip->INODE.i_block[i] == 0) { return 0; }
        //load to mem
        get_block(pip->dev, pip->INODE.i_block[i], buf);
        dp = (DIR *)buf;
        dp2 = (DIR *)buf;
        dpPrev = (DIR *)buf;
        cp = buf;
        cp2 = buf;

        while(cp < buf+BLKSIZE && !found)
        {
        memset(temp, 0, 256);
        strncpy(temp, dp->name, dp->name_len);
        if(strcmp(child, temp) == 0)
        {
            //if only child
            if(cp == buf && dp->rec_len == BLKSIZE)
            {
            //deallocate
            bdalloc(pip->dev, pip->INODE.i_block[i]);
            pip->INODE.i_block[i] = 0;
            pip->INODE.i_blocks--;
            found = 1;
            }
            //else delete child
            else
            {
                while((dp2->rec_len + cp2) < buf+BLKSIZE)
                {
                    dpPrev = dp2;
                    cp2 += dp2->rec_len;
                    dp2 = (DIR*)cp2;
                }
                if(dp2 == dp)
                {
                    dpPrev->rec_len += dp->rec_len;
                    found = 1;
                }
                else
                {
                    size = ((buf + BLKSIZE) - (cp + dp->rec_len));
                    dp2->rec_len += dp->rec_len;
                    //copy
                    memmove(cp, (cp + dp->rec_len), size);
                    dpPrev = (DIR*)cp;
                    memset(temp, 0, 256);
                    strncpy(temp, dpPrev->name, dpPrev->name_len);
                    found = 1;
                }
            }
        }
        cp += dp->rec_len;
        dp = (DIR*)cp;
        }
        if(found)
        {
        //putback to disk
        put_block(pip->dev, pip->INODE.i_block[i], buf);
        return 1;
        }
    }
    return -1;
}

int _rm(MINODE *mip)
{
    int i, j;
    int buf[256], buf2[256];

    if(!S_ISLNK(mip->INODE.i_mode))
    {
        for(i = 0; i < 12; i++)
        {
            if(mip->INODE.i_block[i] != 0)
                bdalloc(mip->dev, mip->INODE.i_block[i]);
        }
        if(mip->INODE.i_block[12] != 0)
        {
            memset(buf, 0, 256);
            get_block(mip->dev, mip->INODE.i_block[12], (char*)buf);
            for(i = 0; i < 256; i++)
                if(buf[i] != 0) {bdalloc(mip->dev, buf[i]);}
            bdalloc(mip->dev, mip->INODE.i_block[12]);
        }
        if(mip->INODE.i_block[13] != 0)
        {
            memset(buf, 0, 256);
            get_block(mip->dev, mip->INODE.i_block[13], (char*)buf);
            for(i = 0; i < 256; i++)
            {
                if(buf[i] != 0)
                {
                    memset(buf2, 0, 256);
                    get_block(mip->dev, buf[i], (char*)buf2);
                    for(j = 0; j < 256; j++)
                    {
                        if(buf2[j] != 0) {bdalloc(mip->dev, buf2[j]);}
                    }
                    bdalloc(mip->dev, buf[i]);
                }
            }
            bdalloc(mip->dev, mip->INODE.i_block[13]);
        }
    }
    //finally ino
    idalloc(mip->dev, mip->ino);
    return 1;
}

int _unlink(char *pathname)
{
    char parent[256], child[256], buf[BLKSIZE], oldPath[512];
    int bnumber, needLen, idealLen, newRec;
    char *cp;
    DIR *dp;
    strcpy(oldPath, pathname);
    //check file
    int ino = getino(dev, pathname);
    if(ino <= 0)
    {
        printf("File DNE\n");
        return -1;
    }
    //check reg or lnk
    MINODE *mip = iget(dev, ino);
    if(!S_ISREG(mip->INODE.i_mode) && !S_ISLNK(mip->INODE.i_mode))
    {
        printf("File not LNK or REG\n");
        iput(mip->dev, mip);
        return -1;
    }
    mip->INODE.i_links_count--;
    if(mip->INODE.i_links_count <= 0)
    {
        _rm(mip);
    }
    dname(oldPath, parent);
    bname(oldPath, child);
    int ino2 = getino(mip->dev, parent);

    //check if there is child
    if(ino2 == -1 || ino2 == 0) {return -1;}
    MINODE *mip2 = iget(mip->dev, ino2);
    iput(mip->dev, mip);
    _rm_child(mip2, child);

    iput(mip->dev, mip2);
}

int _symlink(char *pathname, char *parameter)
{
    int ino;
    if((ino = getino(dev, pathname))<= 0)
    {
        printf("File DNE\n");
        return -1;
    }
    //create file
    _creat(parameter);
    if(0 >= (ino = getino(dev, parameter))){return -1;}
    MINODE *mip = iget(dev, ino);
    mip->INODE.i_mode = 0120000; //symlink
    mip->dirty = 1;

    strcpy((char*)mip->INODE.i_block, pathname);
    iput(mip->dev, mip);
}